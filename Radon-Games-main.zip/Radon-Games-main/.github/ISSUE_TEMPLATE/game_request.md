---
name: 🎮 Game request
about: Request a game for us to add!
title: ''
labels: game request
assignees: ''

---

**Name of Game**
The name of the game you want to request.

**Description**
A brief description of the game (so we add the right one).

**URL**
The URL of the game's website or a playable version of the game.

**Additional information**
Add any other information about the game here.
